console.log('🌟 Initializing SFB WhatsApp Bot...');

const { startBot } = require('./main.js');

// Start the bot
startBot().catch(err => {
    console.error('💥 Failed to start WhatsApp bot:', err);
    process.exit(1);
});
const settings = {
  packname: 'SFB Bot',
  author: 'SFB',
  botName: "بوت المراقبة والتحكم",
  botOwner: 'iisfbx',
  ownerNumber: '966557424410', // ضع رقمك هنا بدون رمز + أو مسافات
  ownerNumbers: ['966557424410', '966503627512'], // قائمة أرقام المالكين
  giphyApiKey: 'qnl7ssQChTdPjsKta2Ax2LMaGXz303tq',
  commandMode: "public",
  description: "بوت واتساب لمراقبة والتحكم في المحتوى",
  version: "1.0.0",
  updateZipUrl: "",
};

module.exports = settings;

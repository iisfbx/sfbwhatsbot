const isAdmin = require('../lib/isAdmin');
const { isOwnerMultiple } = require('../lib/index');

const channelInfo = {
    contextInfo: {
        forwardingScore: 1,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: '120363401722607950@newsletter',
            newsletterName: 'SFB Bot',
            serverMessageId: -1
        }
    }
};

async function muteCommand(sock, chatId, senderId, durationInMinutes, message) {
    console.log(`محاولة كتم المجموعة لمدة ${durationInMinutes} دقيقة`);

    const { isSenderAdmin, isBotAdmin } = await isAdmin(sock, chatId, senderId, message);
    const senderIsOwner = await isOwnerMultiple(senderId, message.key.fromMe);

    if (!isBotAdmin) {
        await sock.sendMessage(chatId, { 
            text: '❌ يجب أن يكون البوت مشرفاً في المجموعة أولاً!',
            ...channelInfo 
        });
        return;
    }

    if (!isSenderAdmin && !senderIsOwner) {
        await sock.sendMessage(chatId, { 
            text: '❌ هذا الأمر متاح للمشرفين والمالك فقط!',
            ...channelInfo 
        });
        return;
    }

    const durationInMilliseconds = durationInMinutes * 60 * 1000;
    try {
        await sock.groupSettingUpdate(chatId, 'announcement'); // كتم المجموعة
        await sock.sendMessage(chatId, { 
            text: `🔇 تم كتم المجموعة لمدة ${durationInMinutes} دقيقة\n\n⏰ سيتم إلغاء الكتم تلقائياً بعد انتهاء الوقت`,
            ...channelInfo 
        });

        setTimeout(async () => {
            try {
                await sock.groupSettingUpdate(chatId, 'not_announcement'); // إلغاء الكتم
                await sock.sendMessage(chatId, { 
                    text: '🔊 تم إلغاء كتم المجموعة تلقائياً',
                    ...channelInfo 
                });
            } catch (unmuteError) {
                console.error('خطأ في إلغاء كتم المجموعة:', unmuteError);
                await sock.sendMessage(chatId, { 
                    text: '❌ حدث خطأ أثناء إلغاء كتم المجموعة. يرجى المحاولة يدوياً.',
                    ...channelInfo 
                });
            }
        }, durationInMilliseconds);
    } catch (error) {
        console.error('خطأ في كتم/إلغاء كتم المجموعة:', error);
        await sock.sendMessage(chatId, { 
            text: '❌ حدث خطأ أثناء كتم المجموعة. يرجى المحاولة مرة أخرى.',
            ...channelInfo 
        });
    }
}

module.exports = muteCommand;

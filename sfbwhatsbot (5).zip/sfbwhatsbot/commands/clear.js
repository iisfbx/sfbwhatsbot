const { isOwnerMultiple } = require('../lib/index');
const isAdmin = require('../lib/isAdmin');
const fs = require('fs');
const path = require('path');

// Channel info for message formatting
const channelInfo = {
    contextInfo: {
        forwardingScore: 1,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: '120363401722607950@newsletter',
            newsletterName: 'iisfbx',
            serverMessageId: -1
        }
    }
};

async function clearCommand(sock, chatId, message, args) {
    try {
        // Check if user is owner or admin
        const senderId = message.key.participant || message.key.remoteJid;
        const isGroup = chatId.endsWith('@g.us');
        
        // Check if sender is owner
        const senderIsOwner = await isOwnerMultiple(senderId, message.key.fromMe);
        
        // Check if sender is admin (only in groups)
        let senderIsAdmin = false;
        let isBotAdmin = false;
        if (isGroup) {
            const adminStatus = await isAdmin(sock, chatId, senderId);
            senderIsAdmin = adminStatus.isSenderAdmin;
            isBotAdmin = adminStatus.isBotAdmin;
        }
        
        // Allow only owner or admin to use this command
        if (!senderIsOwner && !senderIsAdmin) {
            await sock.sendMessage(chatId, { 
                text: '❌ هذا الأمر متاح للمالك والمشرفين فقط!',
                ...channelInfo
            });
            return;
        }

        // Check if bot is admin (required to delete other people's messages in groups)
        if (isGroup && !isBotAdmin) {
            await sock.sendMessage(chatId, { 
                text: '❌ يجب أن يكون البوت مشرفاً لحذف رسائل الأعضاء!',
                ...channelInfo
            });
            return;
        }

        // Get the number of messages to delete from args
        let numberOfMessages = parseInt(args[0]) || 10;
        
        // Limit to maximum 100 messages for safety
        if (numberOfMessages > 100) {
            numberOfMessages = 100;
            await sock.sendMessage(chatId, { 
                text: '⚠️ تم تقليل العدد إلى الحد الأقصى (100 رسالة) لضمان الأمان',
                ...channelInfo
            });
        }
        
        if (numberOfMessages < 1) {
            await sock.sendMessage(chatId, { 
                text: '❌ يجب أن يكون عدد الرسائل أكبر من 0\n\n📝 الاستخدام: .clear [عدد الرسائل]\n💡 مثال: .clear 50',
                ...channelInfo
            });
            return;
        }

        // Add confirmation for large deletions
        if (numberOfMessages > 20) {
            const confirmationMsg = await sock.sendMessage(chatId, {
                text: `⚠️ هل أنت متأكد من حذف ${numberOfMessages} رسالة؟\n\n✅ رد بكلمة "نعم" للتأكيد\n❌ رد بكلمة "لا" للإلغاء\n\n⏱️ سيتم الإلغاء تلقائياً خلال 30 ثانية`,
                ...channelInfo
            }, { quoted: message });

            // Wait for confirmation
            return new Promise((resolve) => {
                const timeout = setTimeout(() => {
                    sock.ev.off('messages.upsert', confirmListener);
                    sock.sendMessage(chatId, {
                        text: '⏰ انتهت مهلة التأكيد - تم إلغاء العملية',
                        ...channelInfo
                    });
                    resolve();
                }, 30000);

                // Listen for confirmation response
                const confirmListener = async (messageUpdate) => {
                    const { messages, type } = messageUpdate;
                    if (type !== 'notify') return;

                    const confirmMsg = messages[0];
                    if (!confirmMsg || confirmMsg.key.remoteJid !== chatId) return;

                    const confirmSender = confirmMsg.key.participant || confirmMsg.key.remoteJid;
                    if (confirmSender !== senderId) return;

                    const confirmText = (
                        confirmMsg.message?.conversation ||
                        confirmMsg.message?.extendedTextMessage?.text ||
                        ''
                    ).trim().toLowerCase();

                    if (confirmText === 'نعم' || confirmText === 'yes') {
                        clearTimeout(timeout);
                        sock.ev.off('messages.upsert', confirmListener);
                        await performClear();
                        resolve();
                    } else if (confirmText === 'لا' || confirmText === 'no') {
                        clearTimeout(timeout);
                        sock.ev.off('messages.upsert', confirmListener);
                        await sock.sendMessage(chatId, {
                            text: '❌ تم إلغاء عملية الحذف',
                            ...channelInfo
                        });
                        resolve();
                    }
                };

                sock.ev.on('messages.upsert', confirmListener);
            });
        } else {
            // Direct deletion for small amounts
            await performClear();
        }

        async function performClear() {
            // Send initial status message
            const statusMessage = await sock.sendMessage(chatId, { 
                text: `🗑️ جاري حذف ${numberOfMessages} رسالة...`,
                ...channelInfo
            });

            let deletedCount = 0;
            let messages = [];
            
            try {
                console.log(`🔍 Attempting to load ${numberOfMessages} messages for chat ${chatId}`);
                
                // Get messages from global message cache (simple approach)
                if (global.messageCache && global.messageCache.has(chatId)) {
                    const chatMessages = global.messageCache.get(chatId);
                    if (chatMessages && chatMessages.length > 0) {
                        // Sort by timestamp (newest first) and get requested number
                        messages = chatMessages
                            .sort((a, b) => (b.messageTimestamp || b.timestamp) - (a.messageTimestamp || a.timestamp))
                            .slice(0, numberOfMessages)
                            .filter(msg => msg && msg.key && msg.key.id);
                        console.log(`📦 Loaded ${messages.length} messages from message cache`);
                    }
                }
                
                // Fallback: Try to get from old baileys_store.json if cache is empty
                if (!messages || messages.length === 0) {
                    try {
                        const storePath = path.join(__dirname, '../baileys_store.json');
                        if (fs.existsSync(storePath)) {
                            const storeData = JSON.parse(fs.readFileSync(storePath, 'utf8'));
                            const chatMessages = [];
                            for (const [messageId, msgData] of Object.entries(storeData)) {
                                if (msgData.key && msgData.key.remoteJid === chatId) {
                                    chatMessages.push({
                                        key: msgData.key,
                                        messageTimestamp: msgData.messageTimestamp || 0
                                    });
                                }
                            }
                            
                            if (chatMessages.length > 0) {
                                messages = chatMessages
                                    .sort((a, b) => b.messageTimestamp - a.messageTimestamp)
                                    .slice(0, numberOfMessages);
                                console.log(`📄 Loaded ${messages.length} messages from baileys_store.json as fallback`);
                            }
                        }
                    } catch (storeError) {
                        console.log('Baileys store file fallback failed:', storeError.message);
                    }
                }
                
                if (!messages || messages.length === 0) {
                    await sock.sendMessage(chatId, { 
                        text: `❌ لم يتم العثور على رسائل للحذف في هذه المحادثة.\n\n💡 هذا قد يحدث للأسباب التالية:\n• البوت لم يحفظ رسائل كافية بعد\n• الرسائل قديمة جداً\n• حدث خطأ في تحميل البيانات\n\n🔄 جرب مرة أخرى لاحقاً أو استخدم عدد أقل من الرسائل`,
                        ...channelInfo
                    });
                    return;
                }
                
                console.log(`🎯 Starting deletion of ${messages.length} messages...`);
                
                // Delete messages one by one with error handling
                for (let i = 0; i < messages.length; i++) {
                    const msg = messages[i];
                    try {
                        if (msg.key && msg.key.id) {
                            await sock.sendMessage(chatId, { 
                                delete: msg.key 
                            });
                            deletedCount++;
                            console.log(`✅ Deleted message ${i + 1}/${messages.length}: ${msg.key.id}`);
                            
                            // Add progressive delay to prevent rate limiting
                            const delay = Math.min(300 + (i * 10), 1000); // Progressive delay up to 1 second
                            await new Promise(resolve => setTimeout(resolve, delay));
                        }
                    } catch (deleteError) {
                        console.error(`❌ Error deleting message ${i + 1}:`, deleteError.message);
                        // Continue with other messages even if one fails
                    }
                    
                    // Update progress every 10 messages
                    if ((i + 1) % 10 === 0) {
                        try {
                            await sock.sendMessage(chatId, {
                                text: `🔄 تم حذف ${deletedCount} من ${messages.length} رسالة...`,
                                ...channelInfo
                            });
                        } catch (progressError) {
                            // Ignore progress message errors
                        }
                    }
                }
                
                // Delete the status message
                if (statusMessage && statusMessage.key) {
                    try {
                        await sock.sendMessage(chatId, { delete: statusMessage.key });
                        deletedCount++;
                    } catch (statusDeleteError) {
                        console.log('Failed to delete status message:', statusDeleteError.message);
                    }
                }
                
                // Send completion message
                const completionMsg = await sock.sendMessage(chatId, { 
                    text: `✅ تمت العملية بنجاح!\n\n📊 النتائج:\n• تم حذف: ${deletedCount} رسالة\n• المطلوب: ${numberOfMessages} رسالة\n• المحادثة: ${isGroup ? 'مجموعة' : 'خاص'}\n\n⏰ وقت العملية: ${new Date().toLocaleTimeString('ar-SA')}`,
                    ...channelInfo
                });
                
                // Delete the completion message after 5 seconds
                setTimeout(async () => {
                    try {
                        if (completionMsg && completionMsg.key) {
                            await sock.sendMessage(chatId, { delete: completionMsg.key });
                        }
                    } catch (error) {
                        console.error('Error deleting completion message:', error);
                    }
                }, 5000);
                
            } catch (error) {
                console.error('❌ Error during clear operation:', error);
                await sock.sendMessage(chatId, { 
                    text: `❌ حدث خطأ أثناء العملية!\n\n📊 تم حذف: ${deletedCount} رسالة من أصل ${numberOfMessages}\n🔍 نوع الخطأ: ${error.message || 'خطأ غير معروف'}\n\n💡 نصائح:\n• جرب عدد أقل من الرسائل\n• تأكد من أن البوت مشرف\n• انتظر قليلاً ثم جرب مرة أخرى`,
                    ...channelInfo
                });
            }
        }

    } catch (error) {
        console.error('❌ Fatal error in clear command:', error);
        await sock.sendMessage(chatId, { 
            text: `❌ حدث خطأ خطير في تنفيذ الأمر!\n\n🔍 تفاصيل الخطأ: ${error.message}\n📞 تواصل مع المطور إذا استمر هذا الخطأ`,
            ...channelInfo
        });
    }
}

module.exports = { clearCommand };
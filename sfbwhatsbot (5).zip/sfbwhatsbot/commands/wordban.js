const { addBannedWord, removeBannedWord, getBannedWords, getModerationSettings, toggleWordModeration } = require('../lib/stickerModeration');
const { isOwnerMultiple } = require('../lib/index');

/**
 * أمر إدارة الكلمات المحظورة - للمالك فقط
 */
async function wordBanCommand(sock, message, args) {
    const from = message.key.remoteJid;
    const sender = message.key.participant || message.key.remoteJid;
    
    // التحقق من أن المرسل هو المالك
    const senderIsOwner = await isOwnerMultiple(sender, message.key.fromMe);
    if (!senderIsOwner) {
        await sock.sendMessage(from, { 
            text: '❌ هذا الأمر متاح للمالك فقط!' 
        }, { quoted: message });
        return;
    }

    if (!args || args.length === 0) {
        const helpText = `
🔧 *إدارة الكلمات المحظورة*

📝 *الأوامر المتاحة:*
• \`!wordban add <كلمة>\` - إضافة كلمة محظورة
• \`!wordban remove <كلمة>\` - حذف كلمة من المحظورات
• \`!wordban list\` - عرض قائمة الكلمات المحظورة
• \`!wordban toggle\` - تفعيل/إلغاء تفعيل مراقبة الكلمات
• \`!wordban status\` - عرض حالة النظام

📌 *مثال:* \`!wordban add كلمة_سيئة\`
        `;
        await sock.sendMessage(from, { text: helpText }, { quoted: message });
        return;
    }

    const action = args[0].toLowerCase();

    switch (action) {
        case 'add':
            await handleAddWordBan(sock, message, from, args.slice(1));
            break;
        case 'remove':
            await handleRemoveWordBan(sock, message, from, args.slice(1));
            break;
        case 'list':
            await handleListBannedWords(sock, message, from);
            break;
        case 'toggle':
            await handleToggleWordModeration(sock, message, from);
            break;
        case 'status':
            await handleWordModerationStatus(sock, message, from);
            break;
        default:
            await sock.sendMessage(from, { 
                text: '❌ أمر غير صحيح. استخدم `!wordban` لعرض قائمة الأوامر.' 
            }, { quoted: message });
    }
}

/**
 * إضافة كلمة إلى المحظورات
 */
async function handleAddWordBan(sock, message, from, wordArgs) {
    try {
        if (!wordArgs || wordArgs.length === 0) {
            await sock.sendMessage(from, { 
                text: '❌ يجب كتابة الكلمة المراد حظرها!\n\n📌 *مثال:* `!wordban add كلمة_سيئة`' 
            }, { quoted: message });
            return;
        }

        const word = wordArgs.join(' ').trim();
        
        if (word.length === 0) {
            await sock.sendMessage(from, { 
                text: '❌ الكلمة لا يمكن أن تكون فارغة!' 
            }, { quoted: message });
            return;
        }

        // إضافة الكلمة إلى المحظورات
        const success = addBannedWord(word);
        
        if (success) {
            await sock.sendMessage(from, { 
                text: `✅ تم إضافة الكلمة "${word}" إلى قائمة المحظورات بنجاح!` 
            }, { quoted: message });
        } else {
            await sock.sendMessage(from, { 
                text: `⚠️ الكلمة "${word}" موجودة مسبقاً في قائمة المحظورات!` 
            }, { quoted: message });
        }
    } catch (error) {
        console.error('خطأ في إضافة الكلمة المحظورة:', error);
        await sock.sendMessage(from, { 
            text: '❌ حدث خطأ أثناء إضافة الكلمة!' 
        }, { quoted: message });
    }
}

/**
 * حذف كلمة من المحظورات
 */
async function handleRemoveWordBan(sock, message, from, wordArgs) {
    try {
        if (!wordArgs || wordArgs.length === 0) {
            await sock.sendMessage(from, { 
                text: '❌ يجب كتابة الكلمة المراد حذفها!\n\n📌 *مثال:* `!wordban remove كلمة_سيئة`' 
            }, { quoted: message });
            return;
        }

        const word = wordArgs.join(' ').trim();
        
        if (word.length === 0) {
            await sock.sendMessage(from, { 
                text: '❌ الكلمة لا يمكن أن تكون فارغة!' 
            }, { quoted: message });
            return;
        }

        // حذف الكلمة من المحظورات
        const success = removeBannedWord(word);
        
        if (success) {
            await sock.sendMessage(from, { 
                text: `✅ تم حذف الكلمة "${word}" من قائمة المحظورات بنجاح!` 
            }, { quoted: message });
        } else {
            await sock.sendMessage(from, { 
                text: `⚠️ الكلمة "${word}" غير موجودة في قائمة المحظورات!` 
            }, { quoted: message });
        }
    } catch (error) {
        console.error('خطأ في حذف الكلمة المحظورة:', error);
        await sock.sendMessage(from, { 
            text: '❌ حدث خطأ أثناء حذف الكلمة!' 
        }, { quoted: message });
    }
}

/**
 * عرض قائمة الكلمات المحظورة
 */
async function handleListBannedWords(sock, message, from) {
    try {
        const bannedWords = getBannedWords();
        
        if (bannedWords.length === 0) {
            await sock.sendMessage(from, { 
                text: '📝 قائمة الكلمات المحظورة فارغة!' 
            }, { quoted: message });
            return;
        }

        // تقسيم القائمة إلى أجزاء إذا كانت طويلة
        const maxWordsPerMessage = 50;
        const chunks = [];
        
        for (let i = 0; i < bannedWords.length; i += maxWordsPerMessage) {
            chunks.push(bannedWords.slice(i, i + maxWordsPerMessage));
        }

        for (let i = 0; i < chunks.length; i++) {
            const chunk = chunks[i];
            const startIndex = i * maxWordsPerMessage;
            
            const listText = `
📝 *قائمة الكلمات المحظورة* ${chunks.length > 1 ? `(${i + 1}/${chunks.length})` : ''}
*العدد الإجمالي:* ${bannedWords.length}

${chunk.map((word, index) => `${startIndex + index + 1}. ${word}`).join('\n')}

💡 لحذف كلمة من القائمة، استخدم: \`!wordban remove <الكلمة>\`
            `;

            await sock.sendMessage(from, { text: listText }, { quoted: message });
            
            // إضافة تأخير بسيط بين الرسائل لتجنب الحظر
            if (i < chunks.length - 1) {
                await new Promise(resolve => setTimeout(resolve, 1000));
            }
        }
    } catch (error) {
        console.error('خطأ في عرض قائمة الكلمات المحظورة:', error);
        await sock.sendMessage(from, { 
            text: '❌ حدث خطأ أثناء عرض القائمة!' 
        }, { quoted: message });
    }
}

/**
 * تفعيل/إلغاء تفعيل مراقبة الكلمات
 */
async function handleToggleWordModeration(sock, message, from) {
    try {
        const newStatus = toggleWordModeration();
        
        if (newStatus !== null) {
            const statusText = newStatus ? 'مُفعل ✅' : 'مُعطل ❌';
            await sock.sendMessage(from, { 
                text: `🔧 تم تغيير حالة مراقبة الكلمات إلى: ${statusText}` 
            }, { quoted: message });
        } else {
            await sock.sendMessage(from, { 
                text: '❌ حدث خطأ أثناء تغيير حالة المراقبة!' 
            }, { quoted: message });
        }
    } catch (error) {
        console.error('خطأ في تغيير حالة مراقبة الكلمات:', error);
        await sock.sendMessage(from, { 
            text: '❌ حدث خطأ أثناء تغيير حالة المراقبة!' 
        }, { quoted: message });
    }
}

/**
 * عرض حالة نظام مراقبة الكلمات
 */
async function handleWordModerationStatus(sock, message, from) {
    try {
        const settings = getModerationSettings();
        const bannedWords = getBannedWords();
        
        const statusText = `
📊 *حالة نظام مراقبة الكلمات*

🔧 *الإعدادات:*
• مراقبة الكلمات: ${settings.wordModeration ? 'مُفعل ✅' : 'مُعطل ❌'}

📝 *الإحصائيات:*
• عدد الكلمات المحظورة: ${bannedWords.length}

💡 استخدم \`!wordban toggle\` لتغيير حالة المراقبة
        `;

        await sock.sendMessage(from, { text: statusText }, { quoted: message });
    } catch (error) {
        console.error('خطأ في عرض حالة النظام:', error);
        await sock.sendMessage(from, { 
            text: '❌ حدث خطأ أثناء عرض حالة النظام!' 
        }, { quoted: message });
    }
}

module.exports = { wordBanCommand };
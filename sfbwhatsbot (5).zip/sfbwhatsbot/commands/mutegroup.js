const isAdmin = require('../lib/isAdmin');
const { isOwnerMultiple } = require('../lib/index');

const channelInfo = {
    contextInfo: {
        forwardingScore: 1,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: '120363401722607950@newsletter',
            newsletterName: 'SFB Bot',
            serverMessageId: -1
        }
    }
};

async function mutegroupCommand(sock, chatId, senderId, durationInMinutes, message) {
    console.log(`محاولة كتم المجموعة لمدة ${durationInMinutes} دقيقة`);

    // التحقق من أن الأمر يتم استخدامه في مجموعة
    const isGroup = chatId.endsWith('@g.us');
    if (!isGroup) {
        await sock.sendMessage(chatId, { 
            text: '❌ هذا الأمر متاح للمجموعات فقط!',
            ...channelInfo 
        });
        return;
    }

    const { isSenderAdmin, isBotAdmin } = await isAdmin(sock, chatId, senderId, message);
    const senderIsOwner = await isOwnerMultiple(senderId, message.key.fromMe);

    if (!isBotAdmin) {
        await sock.sendMessage(chatId, { 
            text: '❌ يجب أن يكون البوت مشرفاً في المجموعة أولاً!',
            ...channelInfo 
        });
        return;
    }

    if (!isSenderAdmin && !senderIsOwner) {
        await sock.sendMessage(chatId, { 
            text: '❌ هذا الأمر متاح للمشرفين والمالك فقط!',
            ...channelInfo 
        });
        return;
    }

    // التحقق من صحة المدة
    if (!durationInMinutes || isNaN(durationInMinutes) || durationInMinutes <= 0) {
        await sock.sendMessage(chatId, { 
            text: '❌ يجب تحديد عدد الدقائق صحيح!\n\n📝 الاستخدام: .mutegroup [الدقائق]\n💡 مثال: .mutegroup 30',
            ...channelInfo 
        });
        return;
    }

    // حد أقصى 1440 دقيقة (24 ساعة)
    if (durationInMinutes > 1440) {
        await sock.sendMessage(chatId, { 
            text: '❌ الحد الأقصى للكتم هو 1440 دقيقة (24 ساعة)!\n\n📝 الاستخدام: .mutegroup [الدقائق]\n💡 مثال: .mutegroup 30',
            ...channelInfo 
        });
        return;
    }

    const durationInMilliseconds = durationInMinutes * 60 * 1000;
    
    try {
        // كتم المجموعة
        await sock.groupSettingUpdate(chatId, 'announcement');
        
        await sock.sendMessage(chatId, { 
            text: `🔇 تم كتم المجموعة لمدة ${durationInMinutes} دقيقة\n\n⏰ سيتم إلغاء الكتم تلقائياً بعد انتهاء الوقت\n📱 يمكن للمشرفين فقط إرسال الرسائل الآن`,
            ...channelInfo 
        });

        // إعداد مؤقت لإلغاء الكتم التلقائي
        setTimeout(async () => {
            try {
                await sock.groupSettingUpdate(chatId, 'not_announcement');
                await sock.sendMessage(chatId, { 
                    text: `🔊 تم إلغاء كتم المجموعة تلقائياً\n\n✅ يمكن لجميع الأعضاء إرسال الرسائل الآن`,
                    ...channelInfo 
                });
                console.log(`✅ تم إلغاء كتم المجموعة تلقائياً: ${chatId}`);
            } catch (unmuteError) {
                console.error('خطأ في إلغاء كتم المجموعة:', unmuteError);
                await sock.sendMessage(chatId, { 
                    text: '❌ حدث خطأ أثناء إلغاء كتم المجموعة تلقائياً. يرجى استخدام .unmutegroup يدوياً.',
                    ...channelInfo 
                });
            }
        }, durationInMilliseconds);

        console.log(`✅ تم كتم المجموعة ${chatId} لمدة ${durationInMinutes} دقيقة`);
        
    } catch (error) {
        console.error('خطأ في كتم المجموعة:', error);
        await sock.sendMessage(chatId, { 
            text: '❌ حدث خطأ أثناء كتم المجموعة. تأكد من أن البوت لديه صلاحيات إدارية.',
            ...channelInfo 
        });
    }
}

async function unmutegroupCommand(sock, chatId, senderId, message) {
    console.log(`محاولة إلغاء كتم المجموعة`);

    // التحقق من أن الأمر يتم استخدامه في مجموعة
    const isGroup = chatId.endsWith('@g.us');
    if (!isGroup) {
        await sock.sendMessage(chatId, { 
            text: '❌ هذا الأمر متاح للمجموعات فقط!',
            ...channelInfo 
        });
        return;
    }

    const { isSenderAdmin, isBotAdmin } = await isAdmin(sock, chatId, senderId, message);
    const senderIsOwner = await isOwnerMultiple(senderId, message.key.fromMe);

    if (!isBotAdmin) {
        await sock.sendMessage(chatId, { 
            text: '❌ يجب أن يكون البوت مشرفاً في المجموعة أولاً!',
            ...channelInfo 
        });
        return;
    }

    if (!isSenderAdmin && !senderIsOwner) {
        await sock.sendMessage(chatId, { 
            text: '❌ هذا الأمر متاح للمشرفين والمالك فقط!',
            ...channelInfo 
        });
        return;
    }

    try {
        // إلغاء كتم المجموعة
        await sock.groupSettingUpdate(chatId, 'not_announcement');
        
        await sock.sendMessage(chatId, { 
            text: `🔊 تم إلغاء كتم المجموعة\n\n✅ يمكن لجميع الأعضاء إرسال الرسائل الآن`,
            ...channelInfo 
        });

        console.log(`✅ تم إلغاء كتم المجموعة: ${chatId}`);
        
    } catch (error) {
        console.error('خطأ في إلغاء كتم المجموعة:', error);
        await sock.sendMessage(chatId, { 
            text: '❌ حدث خطأ أثناء إلغاء كتم المجموعة. تأكد من أن البوت لديه صلاحيات إدارية.',
            ...channelInfo 
        });
    }
}

module.exports = {
    mutegroupCommand,
    unmutegroupCommand
};
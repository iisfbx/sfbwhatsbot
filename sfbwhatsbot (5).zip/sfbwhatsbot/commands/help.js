const settings = require('../settings');
const fs = require('fs');
const path = require('path');

async function helpCommand(sock, chatId, message) {
    const helpMessage = `
╔═══════════════════╗
   *🤖 ${settings.botName || 'بوت المراقبة والتحكم'}*  
   الإصدار: *${settings.version || '1.0.0'}*
   بواسطة ${settings.botOwner || 'SFB Owner'}
╚═══════════════════╝

*الأوامر المتاحة:*

╔═══════════════════╗
🌐 *الأوامر العامة*:
║ ➤ .help أو .menu - عرض قائمة الأوامر
║ ➤ .ping - فحص سرعة الاستجابة
║ ➤ .alive - فحص حالة البوت
║ ➤ .owner - معلومات المالك
║ ➤ .groupinfo - معلومات المجموعة
║ ➤ .staff - عرض قائمة المشرفين
╚═══════════════════╝ 

╔═══════════════════╗
👮‍♂️ *أوامر الإدارة*:
║ ➤ .ban @user - حظر عضو
║ ➤ .unban @user - إلغاء حظر عضو
║ ➤ .promote @user - ترقية عضو
║ ➤ .demote @user - خفض رتبة عضو
║ ➤ .mute <دقائق> - كتم المجموعة
║ ➤ .unmute - إلغاء كتم المجموعة
║ ➤ .usermute @user <دقائق> - كتم عضو محدد
║ ➤ .userunmute @user - إلغاء كتم العضو
║ ➤ .delete أو .del - حذف رسالة
║ ➤ .kick @user - طرد عضو
║ ➤ .warn @user - إنذار عضو
║ ➤ .warnings @user - عرض الإنذارات
║ ➤ .clear [العدد] - حذف رسائل (افتراضي: 10)
║ ➤ .tag <رسالة> - تاج مع رسالة
║ ➤ .tagall - تاج جميع الأعضاء
║ ➤ .resetlink - تغيير رابط المجموعة
║ ➤ .antilink <on/off> - منع الروابط
╚═══════════════════╝

╔═══════════════════╗
🔒 *أوامر المالك فقط*:
║ ➤ .mode - تغيير وضع البوت (عام/خاص)
║ ➤ .stickerban add - إضافة ملصق محظور (رد على ملصق)
║ ➤ .stickerban remove - حذف ملصق محظور (رد على ملصق)
║ ➤ .stickerban list - عرض الملصقات المحظورة
║ ➤ .stickerban toggle - تفعيل/إلغاء مراقبة الملصقات
║ ➤ .stickerban status - حالة مراقبة الملصقات
║ ➤ .wordban add <كلمة> - إضافة كلمة محظورة
║ ➤ .wordban remove <كلمة> - حذف كلمة محظورة
║ ➤ .wordban list - عرض الكلمات المحظورة
║ ➤ .wordban toggle - تفعيل/إلغاء مراقبة الكلمات
║ ➤ .wordban status - حالة مراقبة الكلمات
║ ➤ .autotyping <on/off> - تفعيل الكتابة التلقائية
║ ➤ .autoread <on/off> - تفعيل القراءة التلقائية
║ ➤ .areact <on/off> - تفعيل التفاعل التلقائي
║ ➤ .antidelete <on/off> - منع حذف الرسائل
║ ➤ .antibadword <on/off> - منع الكلمات السيئة
║ ➤ .chatbot <on/off> - تفعيل الدردشة الذكية
║ ➤ .welcome <on/off> - رسائل الترحيب
║ ➤ .goodbye <on/off> - رسائل الوداع
║ ➤ .setpp - تغيير صورة البروفايل (رد على صورة)
║ ➤ .clearsession - مسح جلسة البوت
║ ➤ .cleartmp - مسح الملفات المؤقتة
║ ➤ .update - تحديث البوت
╚═══════════════════╝

╔═══════════════════╗
🎨 *أوامر الصور والملصقات*:
║ ➤ .sticker - تحويل صورة لملصق (رد على صورة)
║ ➤ .simage - تحويل ملصق لصورة (رد على ملصق)
║ ➤ .take <اسم> - تغيير اسم الملصق
╚═══════════════════╝  

╔═══════════════════╗
🎮 *أوامر الألعاب*:
║ ➤ .tictactoe @user - لعبة إكس أو
║ ➤ .truth - سؤال صراحة
║ ➤ .dare - تحدي
╚═══════════════════╝
    `;

    try {
        // Try to read the bot image
        const imagePath = path.join(__dirname, '../assets/bot_image.jpg');

        if (fs.existsSync(imagePath)) {
            const imageBuffer = fs.readFileSync(imagePath);

            await sock.sendMessage(chatId, {
                image: imageBuffer,
                caption: helpMessage,
                contextInfo: {
                    forwardingScore: 1,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: '120363401722607950@newsletter',
                        newsletterName: 'iisfbx',
                        serverMessageId: -1
                    }
                }
            }, { quoted: message });
        } else {
            // Send text only if image not found
            await sock.sendMessage(chatId, {
                text: helpMessage,
                contextInfo: {
                    forwardingScore: 1,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: '120363401722607950@newsletter',
                        newsletterName: 'iisfbx',
                        serverMessageId: -1
                    }
                }
            }, { quoted: message });
        }
    } catch (error) {
        console.error('Error in help command:', error);
        // Fallback to text message
        await sock.sendMessage(chatId, {
            text: helpMessage
        }, { quoted: message });
    }
}

module.exports = helpCommand;
const { addBannedSticker, removeBannedSticker, getBannedStickers, getModerationSettings, toggleStickerModeration } = require('../lib/stickerModeration');
const { isOwnerMultiple } = require('../lib/index');

/**
 * أمر إدارة الملصقات المحظورة - للمالك فقط
 */
async function stickerBanCommand(sock, message, args) {
    const from = message.key.remoteJid;
    const sender = message.key.participant || message.key.remoteJid;
    
    // التحقق من أن المرسل هو المالك
    const senderIsOwner = await isOwnerMultiple(sender, message.key.fromMe);
    if (!senderIsOwner) {
        await sock.sendMessage(from, { 
            text: '❌ هذا الأمر متاح للمالك فقط!' 
        }, { quoted: message });
        return;
    }

    if (!args || args.length === 0) {
        const helpText = `
🔧 *إدارة الملصقات المحظورة*

📝 *الأوامر المتاحة:*
• \`!stickerban add\` - إضافة ملصق محظور (رد على الملصق)
• \`!stickerban remove\` - حذف ملصق من المحظورات (رد على الملصق)
• \`!stickerban list\` - عرض قائمة الملصقات المحظورة
• \`!stickerban toggle\` - تفعيل/إلغاء تفعيل مراقبة الملصقات
• \`!stickerban status\` - عرض حالة النظام

📌 *ملاحظة:* للإضافة أو الحذف، قم بالرد على الملصق المطلوب مع الأمر.
        `;
        await sock.sendMessage(from, { text: helpText }, { quoted: message });
        return;
    }

    const action = args[0].toLowerCase();

    switch (action) {
        case 'add':
            await handleAddStickerBan(sock, message, from);
            break;
        case 'remove':
            await handleRemoveStickerBan(sock, message, from);
            break;
        case 'list':
            await handleListBannedStickers(sock, message, from);
            break;
        case 'toggle':
            await handleToggleStickerModeration(sock, message, from);
            break;
        case 'status':
            await handleModerationStatus(sock, message, from);
            break;
        default:
            await sock.sendMessage(from, { 
                text: '❌ أمر غير صحيح. استخدم `!stickerban` لعرض قائمة الأوامر.' 
            }, { quoted: message });
    }
}

/**
 * إضافة ملصق إلى المحظورات
 */
async function handleAddStickerBan(sock, message, from) {
    try {
        // التحقق من وجود رد على رسالة
        if (!message.message.extendedTextMessage || !message.message.extendedTextMessage.contextInfo) {
            await sock.sendMessage(from, { 
                text: '❌ يجب الرد على الملصق المراد حظره!' 
            }, { quoted: message });
            return;
        }

        const quotedMessage = message.message.extendedTextMessage.contextInfo.quotedMessage;
        
        // التحقق من أن الرسالة المردود عليها ملصق
        if (!quotedMessage || !quotedMessage.stickerMessage) {
            await sock.sendMessage(from, { 
                text: '❌ يجب الرد على ملصق صحيح!' 
            }, { quoted: message });
            return;
        }

        // الحصول على معرف الملصق
        const stickerData = quotedMessage.stickerMessage;
        const stickerId = stickerData.fileSha256 ? Buffer.from(stickerData.fileSha256).toString('hex') : 
                         stickerData.url || 'unknown_' + Date.now();

        // إضافة الملصق إلى المحظورات
        const success = addBannedSticker(stickerId);
        
        if (success) {
            await sock.sendMessage(from, { 
                text: '✅ تم إضافة الملصق إلى قائمة المحظورات بنجاح!' 
            }, { quoted: message });
        } else {
            await sock.sendMessage(from, { 
                text: '⚠️ الملصق موجود مسبقاً في قائمة المحظورات!' 
            }, { quoted: message });
        }
    } catch (error) {
        console.error('خطأ في إضافة الملصق المحظور:', error);
        await sock.sendMessage(from, { 
            text: '❌ حدث خطأ أثناء إضافة الملصق!' 
        }, { quoted: message });
    }
}

/**
 * حذف ملصق من المحظورات
 */
async function handleRemoveStickerBan(sock, message, from) {
    try {
        // التحقق من وجود رد على رسالة
        if (!message.message.extendedTextMessage || !message.message.extendedTextMessage.contextInfo) {
            await sock.sendMessage(from, { 
                text: '❌ يجب الرد على الملصق المراد حذفه من المحظورات!' 
            }, { quoted: message });
            return;
        }

        const quotedMessage = message.message.extendedTextMessage.contextInfo.quotedMessage;
        
        // التحقق من أن الرسالة المردود عليها ملصق
        if (!quotedMessage || !quotedMessage.stickerMessage) {
            await sock.sendMessage(from, { 
                text: '❌ يجب الرد على ملصق صحيح!' 
            }, { quoted: message });
            return;
        }

        // الحصول على معرف الملصق
        const stickerData = quotedMessage.stickerMessage;
        const stickerId = stickerData.fileSha256 ? Buffer.from(stickerData.fileSha256).toString('hex') : 
                         stickerData.url || 'unknown_' + Date.now();

        // حذف الملصق من المحظورات
        const success = removeBannedSticker(stickerId);
        
        if (success) {
            await sock.sendMessage(from, { 
                text: '✅ تم حذف الملصق من قائمة المحظورات بنجاح!' 
            }, { quoted: message });
        } else {
            await sock.sendMessage(from, { 
                text: '⚠️ الملصق غير موجود في قائمة المحظورات!' 
            }, { quoted: message });
        }
    } catch (error) {
        console.error('خطأ في حذف الملصق المحظور:', error);
        await sock.sendMessage(from, { 
            text: '❌ حدث خطأ أثناء حذف الملصق!' 
        }, { quoted: message });
    }
}

/**
 * عرض قائمة الملصقات المحظورة
 */
async function handleListBannedStickers(sock, message, from) {
    try {
        const bannedStickers = getBannedStickers();
        
        if (bannedStickers.length === 0) {
            await sock.sendMessage(from, { 
                text: '📝 قائمة الملصقات المحظورة فارغة!' 
            }, { quoted: message });
            return;
        }

        const listText = `
📝 *قائمة الملصقات المحظورة* (${bannedStickers.length})

${bannedStickers.map((id, index) => `${index + 1}. ${id.substring(0, 20)}...`).join('\n')}

💡 لحذف ملصق من القائمة، ارسل الملصق ثم رد عليه بـ \`!stickerban remove\`
        `;

        await sock.sendMessage(from, { text: listText }, { quoted: message });
    } catch (error) {
        console.error('خطأ في عرض قائمة الملصقات المحظورة:', error);
        await sock.sendMessage(from, { 
            text: '❌ حدث خطأ أثناء عرض القائمة!' 
        }, { quoted: message });
    }
}

/**
 * تفعيل/إلغاء تفعيل مراقبة الملصقات
 */
async function handleToggleStickerModeration(sock, message, from) {
    try {
        const newStatus = toggleStickerModeration();
        
        if (newStatus !== null) {
            const statusText = newStatus ? 'مُفعل ✅' : 'مُعطل ❌';
            await sock.sendMessage(from, { 
                text: `🔧 تم تغيير حالة مراقبة الملصقات إلى: ${statusText}` 
            }, { quoted: message });
        } else {
            await sock.sendMessage(from, { 
                text: '❌ حدث خطأ أثناء تغيير حالة المراقبة!' 
            }, { quoted: message });
        }
    } catch (error) {
        console.error('خطأ في تغيير حالة مراقبة الملصقات:', error);
        await sock.sendMessage(from, { 
            text: '❌ حدث خطأ أثناء تغيير حالة المراقبة!' 
        }, { quoted: message });
    }
}

/**
 * عرض حالة نظام المراقبة
 */
async function handleModerationStatus(sock, message, from) {
    try {
        const settings = getModerationSettings();
        const bannedStickers = getBannedStickers();
        
        const statusText = `
📊 *حالة نظام مراقبة الملصقات*

🔧 *الإعدادات:*
• مراقبة الملصقات: ${settings.stickerModeration ? 'مُفعل ✅' : 'مُعطل ❌'}

📝 *الإحصائيات:*
• عدد الملصقات المحظورة: ${bannedStickers.length}

💡 استخدم \`!stickerban toggle\` لتغيير حالة المراقبة
        `;

        await sock.sendMessage(from, { text: statusText }, { quoted: message });
    } catch (error) {
        console.error('خطأ في عرض حالة النظام:', error);
        await sock.sendMessage(from, { 
            text: '❌ حدث خطأ أثناء عرض حالة النظام!' 
        }, { quoted: message });
    }
}

module.exports = { stickerBanCommand };
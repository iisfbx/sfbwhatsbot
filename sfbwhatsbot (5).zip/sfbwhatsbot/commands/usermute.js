const isAdmin = require('../lib/isAdmin');
const { isOwnerMultiple } = require('../lib/index');
const fs = require('fs');
const path = require('path');

const channelInfo = {
    contextInfo: {
        forwardingScore: 1,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: '120363401722607950@newsletter',
            newsletterName: 'SFB Bot',
            serverMessageId: -1
        }
    }
};

// دوال للتحكم في الأعضاء المكتومين
function loadMutedUsers() {
    try {
        const mutedUsersPath = path.join(__dirname, '../data/mutedUsers.json');
        if (fs.existsSync(mutedUsersPath)) {
            return JSON.parse(fs.readFileSync(mutedUsersPath, 'utf8'));
        }
        return { mutedUsers: {} };
    } catch (error) {
        console.error('خطأ في تحميل المستخدمين المكتومين:', error);
        return { mutedUsers: {} };
    }
}

function saveMutedUsers(data) {
    try {
        const mutedUsersPath = path.join(__dirname, '../data/mutedUsers.json');
        fs.writeFileSync(mutedUsersPath, JSON.stringify(data, null, 2));
        return true;
    } catch (error) {
        console.error('خطأ في حفظ المستخدمين المكتومين:', error);
        return false;
    }
}

async function userMuteCommand(sock, chatId, senderId, mentionedJids, durationInMinutes, message) {
    console.log(`محاولة كتم عضو لمدة ${durationInMinutes} دقيقة`);

    const { isSenderAdmin, isBotAdmin } = await isAdmin(sock, chatId, senderId, message);
    const senderIsOwner = await isOwnerMultiple(senderId, message.key.fromMe);

    if (!isBotAdmin) {
        await sock.sendMessage(chatId, { 
            text: '❌ يجب أن يكون البوت مشرفاً في المجموعة أولاً!',
            ...channelInfo 
        });
        return;
    }

    if (!isSenderAdmin && !senderIsOwner) {
        await sock.sendMessage(chatId, { 
            text: '❌ هذا الأمر متاح للمشرفين والمالك فقط!',
            ...channelInfo 
        });
        return;
    }

    if (!mentionedJids || mentionedJids.length === 0) {
        await sock.sendMessage(chatId, { 
            text: '❌ يجب منشن العضو المراد كتمه!\n\n📝 الاستخدام: .usermute @عضو [الوقت بالدقائق]\n💡 مثال: .usermute @966501234567 30',
            ...channelInfo 
        }, { quoted: message });
        return;
    }

    const targetUserId = mentionedJids[0];
    const targetUserNumber = targetUserId.replace('@s.whatsapp.net', '').replace('@c.us', '');

    // التحقق من أن العضو المستهدف ليس مالكاً أو مشرفاً
    const targetIsOwner = await isOwnerMultiple(targetUserId);
    const { isSenderAdmin: targetIsAdmin } = await isAdmin(sock, chatId, targetUserId, message);

    if (targetIsOwner) {
        await sock.sendMessage(chatId, { 
            text: '❌ لا يمكن كتم مالك البوت!',
            ...channelInfo 
        });
        return;
    }

    if (targetIsAdmin && !senderIsOwner) {
        await sock.sendMessage(chatId, { 
            text: '❌ لا يمكن للمشرفين كتم مشرفين آخرين! فقط المالك يستطيع فعل ذلك.',
            ...channelInfo 
        });
        return;
    }

    try {
        const data = loadMutedUsers();
        
        if (!data.mutedUsers[chatId]) {
            data.mutedUsers[chatId] = {};
        }

        const muteEndTime = Date.now() + (durationInMinutes * 60 * 1000);
        data.mutedUsers[chatId][targetUserId] = {
            mutedBy: senderId,
            muteEndTime: muteEndTime,
            duration: durationInMinutes
        };

        saveMutedUsers(data);

        await sock.sendMessage(chatId, { 
            text: `🔇 تم كتم @${targetUserNumber} لمدة ${durationInMinutes} دقيقة\n\n⏰ سيتم إلغاء الكتم تلقائياً بعد انتهاء الوقت\n📝 جميع رسائل العضو ستحذف تلقائياً أثناء فترة الكتم`,
            mentions: [targetUserId],
            ...channelInfo 
        }, { quoted: message });

        // إزالة الكتم تلقائياً بعد انتهاء الوقت
        setTimeout(async () => {
            try {
                const currentData = loadMutedUsers();
                if (currentData.mutedUsers[chatId] && currentData.mutedUsers[chatId][targetUserId]) {
                    delete currentData.mutedUsers[chatId][targetUserId];
                    saveMutedUsers(currentData);

                    await sock.sendMessage(chatId, { 
                        text: `🔊 تم إلغاء كتم @${targetUserNumber} تلقائياً`,
                        mentions: [targetUserId],
                        ...channelInfo 
                    });
                }
            } catch (error) {
                console.error('خطأ في إلغاء كتم العضو:', error);
            }
        }, durationInMinutes * 60 * 1000);

    } catch (error) {
        console.error('خطأ في كتم العضو:', error);
        await sock.sendMessage(chatId, { 
            text: '❌ حدث خطأ أثناء كتم العضو. يرجى المحاولة مرة أخرى.',
            ...channelInfo 
        });
    }
}

// دالة للتحقق من أن العضو مكتوم
function isUserMuted(chatId, userId) {
    try {
        const data = loadMutedUsers();
        if (data.mutedUsers[chatId] && data.mutedUsers[chatId][userId]) {
            const muteInfo = data.mutedUsers[chatId][userId];
            if (Date.now() < muteInfo.muteEndTime) {
                return true;
            } else {
                // إزالة الكتم المنتهي الصلاحية
                delete data.mutedUsers[chatId][userId];
                saveMutedUsers(data);
                return false;
            }
        }
        return false;
    } catch (error) {
        console.error('خطأ في فحص كتم العضو:', error);
        return false;
    }
}

// دالة لإلغاء كتم عضو يدوياً
async function userUnmuteCommand(sock, chatId, senderId, mentionedJids, message) {
    const { isSenderAdmin, isBotAdmin } = await isAdmin(sock, chatId, senderId, message);
    const senderIsOwner = await isOwnerMultiple(senderId, message.key.fromMe);

    if (!isBotAdmin) {
        await sock.sendMessage(chatId, { 
            text: '❌ يجب أن يكون البوت مشرفاً في المجموعة أولاً!',
            ...channelInfo 
        });
        return;
    }

    if (!isSenderAdmin && !senderIsOwner) {
        await sock.sendMessage(chatId, { 
            text: '❌ هذا الأمر متاح للمشرفين والمالك فقط!',
            ...channelInfo 
        });
        return;
    }

    if (!mentionedJids || mentionedJids.length === 0) {
        await sock.sendMessage(chatId, { 
            text: '❌ يجب منشن العضو المراد إلغاء كتمه!\n\n📝 الاستخدام: .userunmute @عضو',
            ...channelInfo 
        }, { quoted: message });
        return;
    }

    const targetUserId = mentionedJids[0];
    const targetUserNumber = targetUserId.replace('@s.whatsapp.net', '').replace('@c.us', '');

    try {
        const data = loadMutedUsers();
        
        if (data.mutedUsers[chatId] && data.mutedUsers[chatId][targetUserId]) {
            delete data.mutedUsers[chatId][targetUserId];
            saveMutedUsers(data);

            await sock.sendMessage(chatId, { 
                text: `🔊 تم إلغاء كتم @${targetUserNumber}`,
                mentions: [targetUserId],
                ...channelInfo 
            }, { quoted: message });
        } else {
            await sock.sendMessage(chatId, { 
                text: '❌ العضو غير مكتوم أصلاً!',
                ...channelInfo 
            });
        }
    } catch (error) {
        console.error('خطأ في إلغاء كتم العضو:', error);
        await sock.sendMessage(chatId, { 
            text: '❌ حدث خطأ أثناء إلغاء كتم العضو. يرجى المحاولة مرة أخرى.',
            ...channelInfo 
        });
    }
}

module.exports = { 
    userMuteCommand, 
    userUnmuteCommand, 
    isUserMuted 
};